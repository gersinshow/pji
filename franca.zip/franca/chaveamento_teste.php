<? include ('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtenha os dados do formulário
    $sigla = $_POST['sigla'];
    $campus = $_POST['campus'];

    // Obtenha o próximo valor único para 'id_unidade'
    $sql = "SELECT nome from pessoa;";
    $result = $conexao->query($sql);
    $row = $result->fetch_assoc();


    // Inserir os dados na tabela 'unidade' com o novo 'id_unidade'


}

// Feche a conexão com o banco de dados
$conexao->close();


?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <meta charset="UTF-8" />
    <link rel="shortcut icon" href="img/Logo.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />

    <title>PJI</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" />
    <link rel="stylesheet" href="css/mdb.min.css" />
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- HEAD Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container d-flex justify-content-center">
            <a class="navbar-brand" href="index.html" id="jif"><img
                    src="img/Logo_JIF_2022_horizontal-PhotoRoom.png-PhotoRoom.png" alt="" style="width: 50px;"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkup">
                <div class="position-absolute top-50 start-50 translate-middle">
                    <div class="navbar-nav">
                        <a class="nav-item nav-link active" href="sobre.html">Sobre o JIF</a>
                        <a class="nav-item nav-link active" href="informacoes.html">Informações</a>
                        <a class="nav-item nav-link active" href="contato.html">Página de contato</a>
                    </div>
                </div>
                <div class="position-absolute top-50 end-0 translate-middle-y p-2">
                    <div class="navbar-nav">
                        <a class="nav-item nav-link active" href="cadastro.html">Cadastro Atleta</a>
                        <a class="nav-item nav-link active" href="sumulas.html">Cadastro Súmulas</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Conteúdo -->


    <div class="container mt-5">
        <h4 class="text-center">Chaveamento JIF </h4>


    </div>

    
    <div>
        <form action="chaveamento_teste.php" method="post">
            <select name="times" id="times">
                
                
                <?php

                for ($i = 0; $i < $id_equipe; $i++){
                    echo '<option value="time'.$i.'">'.$row.'</option>';
                    echo '<input type="submit" value="enviar">';
                }
            

                 
                 ?>
            </select>

        </form>
    </div>
    
<button type="submit">enviar</button>
    <!-- Footer Rodapé -->
    <footer class="bg-light text-center text-lg-start fixed-bottom">
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            © 2023 Copyright:
            <a class="text-dark" href="#">Mariazinha's Team</a>
        </div>
    </footer>

    <!-- Scripts -->
    <script type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="js/checkout.js"></script>
</body>

</html>