<?php
include('config.php');

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

$sql = "SELECT MAX(id_unidade) AS max_id FROM unidade";
$result = $conexao->query($sql);
$row = $result->fetch_assoc();
$next_id = $row['max_id'] + 1;

$retorna = []; // Inicialize $retorna fora do bloco if

if (isset($dados['sigla']) && isset($dados['campus']) && $dados['sigla'] !== '' && $dados['campus'] !== '') {
    $query_usuario = "INSERT INTO unidade (id_unidade, sigla_instituicao, campus) VALUES (?, ?, ?)";
    $cad_usuario = $conexao->prepare($query_usuario);
    $cad_usuario->bind_param('iss', $next_id, $dados['sigla'], $dados['campus']);
    $cad_usuario->execute();

    if ($cad_usuario->affected_rows > 0) {
        // Buscar novamente os dados da tabela após a inserção bem-sucedida
        $retorna['data'] = fetchDataFromTable();
        $retorna['status'] = true;
        $retorna['msg'] = "Unidade Inserida com Sucesso!";
    } else {
        $retorna['status'] = false;
        $retorna['msg'] = "Erro: Unidade não Inserida!";
    }

    $cad_usuario->close();
} else {
    $retorna['status'] = false;
    $retorna['msg'] = "Erro: Campos 'sigla' e 'campus' são obrigatórios!";
}

echo json_encode($retorna);

function fetchDataFromTable() {
    global $conexao;

    $sql = "SELECT * FROM unidade";
    $result = $conexao->query($sql);

    if ($result !== false && $result->num_rows > 0) {
        $data = array();

        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    } else {
        return [];
    }
}
?>
