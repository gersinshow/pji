<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_2/style.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
    <title>Tipo de Cadastro</title>
</head>

<body>
    <div class="boxzinha">
        <div class="img-boxzinha">
            <img src="css_2/img-formulario.png">
        </div>
        <div class="formulario-boxzinha">
            <h2>Tipo de Cadastro</h2>

            <form action="redirecionar.php" method="post">
                <div class="inputszinha">
                    <br><br>
                    <label for="tipo">Função:</label>

                    <select name="tipo" id="tipo">
                        <option value="atleta">Atleta</option>
                        <option value="chefe_delegacao">Chefe de Delegação</option>
                        <option value="arbitro">Árbitro</option>
                    </select>
                    <br><br><br><br>
                    <button type="submit">Continuar</button>
                </div>
                <br>
                
            </form>
        </div>
    </div>
</body>

</html>
