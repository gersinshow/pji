<?php
session_start();
include('config.php');

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

// Obter o tipo de pessoa a partir do parâmetro da URL
$tipo_pessoa_param = isset($_GET["tipo"]) ? $_GET["tipo"] : (isset($_POST["tipo"]) ? $_POST["tipo"] : "");

// Mapear o tipo de pessoa para o ID correspondente
$tipos_mapeados = [
    'atleta' => 1,
    'chefe' => 2,
    'outros' => 3,
];

// Verificar se o tipo de pessoa é válido
if ($tipo_pessoa_param && array_key_exists($tipo_pessoa_param, $tipos_mapeados)) {
    // Tipo de pessoa é válido
    $tipo_pessoa_id = $tipos_mapeados[$tipo_pessoa_param];
    //echo "Tipo de pessoa param: " . $tipo_pessoa_param;  // Debug
} else {
    // Tipo de pessoa inválido, redirecionar ou tratar conforme necessário
    //die("Tipo de pessoa inválido. Tipo de pessoa param: " . $tipo_pessoa_param);  // Debug
}

if(isset($_POST['submit'])) {

    if ($_SERVER['REQUEST_METHOD'] === 'POST') 
    {
        // Obter os valores do formulário
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $data_nasc = $_POST['data_nasc'];
        $sexo = $_POST['sexo'];

        if ($conexao->connect_error) {
            die("Erro na conexão com o banco de dados: " . $conexao->connect_error);
        }

        $sql_pessoa = "INSERT INTO pessoa (cpf, nome, sexo, datanasc, tipo_pessoa_id) 
                    VALUES ('$cpf', '$nome', '$sexo', '$data_nasc', '$tipo_pessoa_id')";

        // if ($conexao->query($sql_pessoa) === TRUE) {
        //     echo "Cadastro realizado com sucesso!";
        // } else {
        //     echo "Erro ao realizar o cadastro: " . $conexao->error;
        // }

    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_2/style.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Cadastro</title>
</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    }
</style>
<body>
    <div class="boxzinha">
        <div class="img-boxzinha">
            <img src="css_2/img-formulario.png">
        </div>
        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Cadastro</h2>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>

            <form action="cadastro_pessoa.php" method="POST">
                   
                <input type="hidden" name="tipo" value="<?php echo $tipo_pessoa_param; ?>">

                <div class="inputszinha">
                    <label for="nome"> Nome Completo</label>
                    <input type="text" id="nome" name = "nome" placeholder="Digite o seu Nome Completo" required>
                </div>

                <div class="inputszinha">
                    <label for="cpf">CPF</label>
                    <input type="text" id="cpf" name = "cpf" placeholder="Digite o seu CPF" required>
                </div>
                <div class="inputszinha">
                    <label for="data_nasc">Data de Nascimento</label>
                    <input type="date" id="data_nasc" name = "data_nasc" required>
                </div>
                <div class="inputszinha">
                    <label> Sexo: </label>
                </div>

                <div class="sexo">
                    <input type="radio" value="M" name="sexo"> Masculino <br>
                    <input type="radio" value="F" name="sexo"> Feminino <br>
                </div>

                <div class="inputszinha">
                    <button type="submit" name = "submit">Cadastrar</button>
                </div>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php
    // Sua lógica PHP aqui
    if (isset($_POST['submit'])) {
        // Sua lógica de processamento aqui

        if ($conexao->query($sql_pessoa) === TRUE) {
            echo "<script>
            Swal.fire({
                text: 'Cadastro Efetuado com Sucesso!',
                icon: 'success',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Fechar'
            });
            </script>";
        } else {
            echo "Erro ao cadastrar atleta: " . $conexao->error;
        }

        $conexao->close();
    }
    ?>
</body>

</html>