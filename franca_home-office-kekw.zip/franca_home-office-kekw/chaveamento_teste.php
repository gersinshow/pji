<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <meta charset="UTF-8" />
    <link rel="shortcut icon" href="img/Logo.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />

    <title>PJI</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" />
    <link rel="stylesheet" href="css/mdb.min.css" />
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- HEAD Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container d-flex justify-content-center">
            <a class="navbar-brand" href="index.html" id="jif"><img
                    src="img/Logo_JIF_2022_horizontal-PhotoRoom.png-PhotoRoom.png" alt="" style="width: 50px;"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkup">
                <div class="position-absolute top-50 start-50 translate-middle">
                    <div class="navbar-nav">
                        <a class="nav-item nav-link active" href="sobre.html">Sobre o JIF</a>
                        <a class="nav-item nav-link active" href="informacoes.html">Informações</a>
                        <a class="nav-item nav-link active" href="contato.html">Página de contato</a>
                    </div>
                </div>
                <div class="position-absolute top-50 end-0 translate-middle-y p-2">
                    <div class="navbar-nav">
                        <a class="nav-item nav-link active" href="cadastro.html">Cadastro Atleta</a>
                        <a class="nav-item nav-link active" href="sumulas.html">Cadastro Súmulas</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Conteúdo -->

    <!-- Formulário de Inscrição do torneio JIF -->
    <div class="container mt-5">
        <h4 class="text-center">Chaveamento JIF <!--  Por aqui algo pra puxar o ano do banco de dados--></h4>

        <!--<div class="container px-2 text-center">
            <div class="w-25 row">
                <div class="col">
                    <div class="w-25 p-3">Time A</div>
                </div>
                <div class="col">
                    <div class="p-3">Time B</div>
                </div>
            </div>
        </div>
-->
<div class="tree">
        <div class="round">
            <div class="match">
                <div class="team">Time 1</div>
                    X
                <div class="team">Time 2</div>
            </div>
            <div class="match">
                <div class="team">Time 3</div>
                    X
                <div class="team">Time 4</div>
            </div>
            <div class="match">
                <div class="team">Time 5</div>
                    X
                <div class="team">Time 6</div>
            </div>
            <div class="match">
                <div class="team">Time 7</div>
                    X
                <div class="team">Time 8</div>
            </div>
        </div>
        <div class="round">
            <div class="match">
                <div class="team">Vencedor 1</div>
                <div class="team">Vencedor 2</div>
            </div>
            <div class="match">
                <div class="team">Vencedor 3</div>
                <div class="team">Vencedor 4</div>
            </div>
        </div>
        <div class="round">
            <div class="match">
                <div class="team">Vencedor 5</div>
                <div class="team">Vencedor 6</div>
            </div>
        </div>
        <div class="round">
            <div class="match">
                <div class="team">Campeão</div>
            </div>
        </div>
    </div>


        <form class="needs-validation" novalidate>

            <br><br><br><br><br><br>
        </form>
    </div>

    <!-- Footer Rodapé -->
    <footer class="bg-light text-center text-lg-start fixed-bottom">
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            © 2023 Copyright:
            <a class="text-dark" href="#">Mariazinha's Team</a>
        </div>
    </footer>

    <!-- Scripts -->
    <script type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="js/checkout.js"></script>
</body>

</html>