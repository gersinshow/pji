<?php
// session_start();

// if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
//     header("Location: login.php");
//     exit();
// }

// $currentPage = isset($_GET['page']) ? $_GET['page'] : 3;

// $previousPage = $currentPage - 1;
// $nextPage = $currentPage + 1;
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_2/style_cadastros-gerais.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Cadastro do Atleta</title>
</head>
<body>
    <div class="container text-center" style="
    background-color: rgba(255, 255, 255, 0.4);
    backdrop-filter: blur(40px);
    padding: 30px 40px;
    width: 800px;
    border-radius: 20px;
    margin-top: 10vw;
    margin-bottom: 16vw;
    ">
        <h1 style="border: 2px solid; border-radius: 20px;">Cadastros Gerais</h1>
        <br>
        <a href="unidades.php"><button type="button" class="btn btn-outline-dark">Cadastrar unidades</button></a>
        <br><br>
        <a href="cadastro_pessoa.php"><button type="button" class="btn btn-outline-dark">Cadastrar pessoas</button></a>
        <br><br>
        <a href="unidades.php"><button type="button" class="btn btn-outline-dark">Cadastrar campeonato</button></a>
        <br><br>
        <a href="cadastro_pessoa.php"><button type="button" class="btn btn-outline-dark">Cadastrar partida</button></a>

        
    </div>
    

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>