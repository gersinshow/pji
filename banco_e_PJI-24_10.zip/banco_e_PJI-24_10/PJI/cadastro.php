<?
    $escolha = $_POST["escolha"];
    if ($escolha == "sim") {
        include_once("cadastros/cadastro_atleta.html");
    } else {
        include_once("cadastros/cadastro_pessoa.html");
    }
?>
