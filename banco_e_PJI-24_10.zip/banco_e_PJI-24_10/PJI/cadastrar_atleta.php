<?
    include_once("config.php");
    
    $cpf=$_POST["cpf"];
    $nome_aluno=$_POST["estudante"];
    $nome_resp=$_POST["responsavel"];
    $rg=$_POST["rg"];
    $ra=$_POST["ra"];
    $sexo=$_POST["sexo"];
    $datanasc=$_POST["datanasc"];
    $rgpdf=$_POST["rgpdf"];
    $fotopdf=$_POST["fotopdf"];

    if(!$conexao){
        die("Falha na conexão: " . mysqli_connect_error());
    }

    $sql= "call inserir_atleta('$rg', '$ra', '$nome_resp', '$rgpdf', '$fotopdf',
    '$cpf', '$nome_aluno', '$sexo', '$datanasc')";

    if(mysqli_query($conexao, $sql)){
        echo "Registro inserido com sucesso.";
    }else{
        echo "Erro: " . $sql . "<br>" . mysqli_error($conexao);
    }
    mysqli_close($conexao);
?>