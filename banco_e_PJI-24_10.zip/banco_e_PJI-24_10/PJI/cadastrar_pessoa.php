<?
    include_once("config.php");
    
    $cpf=$_POST["cpf"];
    $nome_aluno=$_POST["estudante"];
    $sexo=$_POST["sexo"];
    $datanasc=$_POST["datanasc"];

    if(!$conexao){
        die("Falha na conexão: " . mysqli_connect_error());
    }

    $sql= "call inserir_pessoa('$cpf', '$nome_aluno', '$sexo', '$datanasc')";

    if(mysqli_query($conexao, $sql)){
        echo "Registro inserido com sucesso.";
    }else{
        echo "Erro: " . $sql . "<br>" . mysqli_error($conexao);
    }
    mysqli_close($conexao);
?>