DELIMITER $$
CREATE PROCEDURE inserir_modalidade(IN id INT, IN nome varchar(20) )
BEGIN
      insert into modalidade(id_modalidade, nome) values (id, nome);
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE inserir_unidade(IN id INT, IN sigla varchar(10), campus varchar(25)  )
BEGIN
      insert into unidade(id_unidade, sigla_instituicao, campus)
           values (id, sigla, campus);
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE inserir_pessoa(IN cpf varchar(11), IN nome varchar(35), 
        sexo varchar(1), datanasc date )
BEGIN
      insert into pessoa(cpf, nome, sexo, datanasc)
           values (cpf, nome, sexo, datanasc);
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE inserir_atleta(IN rg varchar(12), IN ra varchar(35), 
		IN responsavel varchar(35), IN foto_rg text, IN foto_rosto text,
        IN cpf varchar(11), IN nome varchar(35), IN sexo varchar(1), datanasc date)
BEGIN
	insert into pessoa(rg, ra, responsavel, foto_rg, foto_rosto, cpf, nome, sexo,
				datanasc)
		values(rg, ra, responsavel, foto_rg, foto_rosto, cpf, nome, sexo, datanasc);
END $$


